import { DefaultAIAnalyzer } from "./aiAnalyzer";
import { AIAnalyzer, AIAnalyzerOptions, LLMProvider } from "./ai.types";
import { NullProvider } from "./providers/null";
import { OpenAIProvider } from "./providers/openai";


export function createAIAnalyzer(opts?: Partial<AIAnalyzerOptions>): AIAnalyzer {
const providerName = opts?.provider ?? (process.env.AI_PROVIDER as any) ?? "null";


let provider: LLMProvider;
if (providerName === "openai") {
provider = new OpenAIProvider(
process.env.OPENAI_API_KEY ?? "",
process.env.OPENAI_MODEL ?? "gpt-4o-mini"
);
} else {
provider = new NullProvider();
}


return new DefaultAIAnalyzer(provider);
}